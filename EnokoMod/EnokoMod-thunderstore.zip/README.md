If you are seeing this, I either forgot to update this file or I accidentally uploaded this mod early.
Things that need to be done before release:
fix dependencies for workshop
think about thunderstore compatibility(should still work)
think of more things to put in this list
